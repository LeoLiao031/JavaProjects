// importing java packages for usage later in the program 
import java.util.Scanner;
import java.util.ArrayList;
import java.lang.Math;
import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.File;
/**
* The Main program is an application that asks the users for information on their appliances inorder to calculate their 
* electricity usage in kilowatt hours. The user is then shown a table that displays their annual kilowatt hour usage of
* electricity, the worlds annual kilowatt hour usage of electricity per capita and the multiple difference between them.
* Another option the user is given is to check the past data of other users who have used the calculator. The same type 
* of data shown in a table created from user input is shown to the user. 
* 
* @author Leo Liao
* @version 1.0
* @since 2021-11-21
*/
class Main {
  // defining variables 
  static Scanner input = new Scanner (System.in);
  static String username;
  static String appliance;
  static double wattage;
  static double usage;
  static double difference = 0;
  static boolean invalid;
  static int familysize;
  static ArrayList<String> appliances = new ArrayList<String>();
  static ArrayList<Double> applianceWatt = new ArrayList<Double>();
  static ArrayList<Double> applianceUsage = new ArrayList<Double>();
  static ArrayList<Double> yearlyEnergyUsage = new ArrayList<Double>();

  /**
  * This method is used to ask the user for information on things that could influence their electricity consumption such 
  * as their familysize, appliances, wattage used by these appliance and how long these appliances are used. This method 
  * also contains error checking to ensure that issues dont occur later due to the users inputs.
  *
  */
  static void logUserInfo(){
    System.out.println("Please enter your name");
    username = input.nextLine();
    invalid = true;
    while (invalid) {
    try{
      System.out.println("Please enter the amount of members in your household");
      familysize = input.nextInt();
      input.nextLine();
      if (familysize>=1)
      invalid = false;
      else 
      System.out.println("Invalid input please try again");
    }
    catch(Exception e){
      System.out.println("Invalid input please try again");
      input.nextLine();
    }
    }// end of while loop for household members 

    // promting the user to answer questions that will determine their electricity usage 
    System.out.println("You will now be prompted to enter all the appliances you use. Enter \"stop\" to the appliance question to signify you're finished\n");
    // while loop that will end once the user enters stop as their input for appliance 
    while (true){
      System.out.println("Please enter the name of your appliance: ");
      appliance = input.nextLine();
      // if statements that will end the loop if the user inputs stop or continue
      if (appliance.equalsIgnoreCase("stop")){
        // ends the loop if the user inputs stop
        break;
      }
      else{
        appliances.add(appliance);
        // asking the user to input the wattage that their appliance has and how often it is used per day
        System.out.println("What is the wattage of your appliance? ");
        // while loop that will keep going until a valid input for wattage is inputted
        invalid = true;
        while (invalid){
          try{
            wattage = input.nextDouble();
            input.nextLine();
            if (wattage>0){ 
            applianceWatt.add(wattage);
            invalid = false;
            }
            else 
            System.out.println("Invalid input please try again");
          }
          catch(Exception e){
           System.out.println("Invalid input please try again");
           input.nextLine();
          }
        } // end of while loop for asking for wattage
        System.out.println("How often do you use this appliance per day in hours? ");
        invalid = true;
        while (invalid){
          try{
            usage = input.nextDouble();
            input.nextLine();
            if (usage>0){
            applianceUsage.add(usage); 
            invalid = false;
            }
            else
            System.out.println("Invalid input please try again");
          }
          catch(Exception e){
            System.out.println("Invalid input please try again");
            input.nextLine();
          } 
        }//end of while loop for asking for how often the appliance is used
      }// end of the else statement for appliance details
    }// end of the while loop for user inputting appliances

  }// end of method for logging user info


  /**
  * This method saves the information that the user entered into the loguserInfo method such as usernames, familysize,
  * annual energy usage and the multiplier different between the two values. It then writes this data into the file name
  * specified via PrintWriter and FileWriter
  *
  * @param filename This parameter is the name of the file that the method will write the information to
  */
  static void saveinfo(String filename){
    try{
      FileWriter w = new FileWriter(filename, true);
      PrintWriter Output = new PrintWriter(w);
      Output.printf("\n%s ,%d ,%f ,%f",username, familysize, totalElectricityUsage(yearlyEnergyUsage),difference);
      Output.close();
    }catch(IOException ioException){

    }
  }// end of save info method

  /**
  * This method outputs the row of a table based off the different parameters to fill in the different sections of the table.
  * It used a print format statement to ensure that it has consistent spacing for when all the rows are combined together into
  * one table. As the columns must be inline with eachother
  *
  * @param name         This parameter is the name of the user who inputted the data
  * @param familysize   This parameter is the amount of family members in the persons family
  * @param annualUsage  This parameter is the annual kWh that the user is using 
  * @param worldAvg     This parameter is the world average for kWh per capita used annually
  * @param difference   This parameter is multiple difference between the two annual values
  */
  static void rowtable(String name, int familysize, double annualUsage, double worldAvg, double difference){
    System.out.printf("\n%-20s|%-20d|%-20.2f|%-20.2f|%.2fx",name,familysize,annualUsage,worldAvg,difference);
  }

  /**
  * This method outputs the past information on the energy usage of users who have used the calculator before. It uses a while
  * loop to go through the pastdata.csv file and outputs all the data into a table for the user to read. It uses a while loop
  * while also calling upon the rowtable() method
  */
  static void pastData(){
    int lineNumber = 0;
      // table that will output all the past data from the users 
      System.out.println("Electricity Usage Table of Past Users");
      System.out.println("Name                |Familysize          |Annual Usage(kWh)   |World Average(kWh)  |Multiplier Difference");
      System.out.println("____________________|____________________|____________________|____________________|_____________________");
    try{
      Scanner fileInput = new Scanner(new File("pastdata.csv"));
      while (fileInput.hasNext()){
        lineNumber++;
        String output = fileInput.nextLine();
        if (lineNumber>1){
        String [] info = output.split(",");
        rowtable(info[0].trim(), Integer.parseInt(info[1].trim()),Double.valueOf(info[2].trim()),worldaverage(),Double.valueOf(info[3]));
        }
        // outputting each row by reading from the file

      } // end of while loop for reading the file
    fileInput.close();
    }
    catch(IOException ioException){

    }
  }// end of past data method

  /** 
  * This method clears the console and leaves it blank again
  */
  static void clearscreen(){
    System.out.print("\033[H\033[2J");
    System.out.flush();
  } // end of clearscreen method

  /** 
  * This method is used to calculate the yearly electricity consumption of the user by taking the wattage of their appliances and
  * the amount of hours that they use these appliances per day
  *
  * @param wattage This parameter is an ArrayList of all the wattages that the user entered for their appliances
  * @param usage   This parameter is an ArrayList of all the hours that the user uses their applianceUsage
  * @return ArrayList<Double> This returns the annual wattage that their appliances use per year
  */
  static ArrayList<Double> calcYearlyEnergy(ArrayList<Double> wattage, ArrayList<Double> usage){
    ArrayList<Double> annualWattage = new ArrayList<Double>();
    // formula for annual usage of electricity = (Wattage × Hours Used Per Day) ÷ 1000 = Daily Kilowatt-hour (kWh) consumption
    // for loop that will loop through the elemnets of each array and calculate annual kWh usage
    for (int i = 0; i < appliances.size(); i++){
      annualWattage.add(wattage.get(i)*usage.get(i)/1000*365);
    }// end of for loop for calculating annual usage
    return annualWattage;
  } // end of method for calculating annualWattage of each device


  /**
  * This method is used to total the all the annual wattages of the users appliances to create a measure similar to the measurement
  * in the csv file kWh a year
  *
  * @param annual  This parameter is an ArrayList that holds all the annual wattages that the appliances use
  * @return double This returns the sum of all the elements in the annual ArrayList 
  */
  static double totalElectricityUsage(ArrayList<Double> annual){
    // for loop that goes through the annual wattage and totals the annual wattage of each appliance
    double total=0;
    for (int x = 0; x<yearlyEnergyUsage.size();x++){
      total += annual.get(x);
    }
    return total; 
  }// end of annual electricity use method


  /**
  * This method is used to calculate the average consumption in kilowatt hours per year per capita. It goes thorough the csv file
  * of all the countries and calculates the average by tallying the total then dividing by the amount of countries
  *
  */
  static double worldaverage (){
    int lineNumber = 0;
    double worldtotal = 0;
    double worldaverage = 0;
    try{
      Scanner fileInput = new Scanner(new File("per-capita-electricity-use.csv"));
      while(fileInput.hasNext()){
        lineNumber++;
        if (lineNumber > 0){
        String output = fileInput.nextLine();
        String [] info = output.split(",");
        worldtotal += Double.parseDouble(info[2].trim());
        }
      }
      fileInput.close();
      worldaverage = worldtotal/lineNumber;
    }
    catch (IOException ioException){
      System.out.println("Something went wrong");
    }
    return worldaverage;
  } // end of method for comparing percentage to world average


  /**
  * This method is used to calculate the multiplier difference between the annual usage of electricity and the worlds average
  * in the case that the annual usage of the user is higher than worlds
  *
  * @param higher      This signifies that the annual usage is higher than the worlds average
  * @param annualusage This is the annual usage of electricity that the user uses
  * @return double     This returns the difference of the annualusage compared to the worldaverage()
  */
  static double difference(String higher, double annualusage){
    double difference = annualusage/worldaverage();
    return difference;
  }


  /**
  * This method is used the calculate the multiplier difference between the annual usage of electricity and the worlds average 
  * in the case that the worlds average is higher than the users annual usage
  *
  * @param annualusage This is the annual usage of electricity that the user uses
  * @return double     This returns the difference of the worldsaverage compared to the annualusage
  */
  static double difference(double annualusage){
    double difference = (-1)*worldaverage()/annualusage;
    return difference;
  }

  /**
  * This method is used to output a table to the user that contains what they inputted in the logUserInfo() method while also
  * outputting calculated values such as the worlds average and the difference between the two averages
  *
  * @param name           This is the username of the person who inputted the information
  * @param familysize     This is the number of members in the persons family
  * @param annualUsage    This is the electrical consumption of the user per year
  * @param worldAvg       This is the worlds average electrical consumption per year per capita
  * @param difference     This is the difference between the annual usage and worldAvg
  *
  */
  static void table(String name, int familysize, double annualUsage, double worldAvg, double difference){
    // table header with the different categories of each row
    System.out.println("Electricity Usage Table");
    System.out.println("Name                |Familysize          |Annual Usage(kWh)   |World Average(kWh)  |Multiplier Difference");
    System.out.println("____________________|____________________|____________________|____________________|_____________________");
    System.out.printf("%-20s|%-20d|%-20.2f|%-20.2f|%.2fx",name,familysize,annualUsage,worldAvg,difference);
  }



  public static void main(String[] args) {
    String option;
    // prompting the user with a menu with the option to either see past usage from other users or see what their wasteage is 
    System.out.println("Welcome to the electricity waste calculator!\nPlease enter \"past\" for the calculated usage of other users or \"log\" to calculate your waste");
    System.out.println("Enter \"exit\" if you want the program to end");
    // while loop that will keep running until user inputs exit
    invalid = true;
    while (invalid){
      System.out.println("");
      option = input.nextLine();
      clearscreen();
      if (option.equalsIgnoreCase("past")){
        pastData();
      }
      else if (option.equalsIgnoreCase("log")){
        logUserInfo();
        clearscreen();
        yearlyEnergyUsage = calcYearlyEnergy(applianceWatt, applianceUsage);
        // if statement that decides which overloaded method to use
        if (worldaverage()<totalElectricityUsage(yearlyEnergyUsage)){
          String type = "higher";
          difference = difference(type, totalElectricityUsage(yearlyEnergyUsage));
        }
        else {
          difference = difference(totalElectricityUsage(yearlyEnergyUsage));
        }
        String file = "pastdata.csv";
        saveinfo(file);
        table(username, familysize, totalElectricityUsage(yearlyEnergyUsage), worldaverage(), difference);
        invalid = true;
      }// end of if statement for log option
      else if (option.equalsIgnoreCase("exit")){
        invalid = false;
      }
      else{
        System.out.println("Invalid option please try again ");
      }
    }// end of while loop
  }
}